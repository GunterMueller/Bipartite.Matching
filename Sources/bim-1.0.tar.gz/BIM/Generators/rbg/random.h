void InitRandom (int seed);
void RandomPermutation (int *perm, int n);
void RandomSubset(int low, int high, int n, int *x);
void RandPerm (int *perm, int n);
int RandomInteger (int low, int high);

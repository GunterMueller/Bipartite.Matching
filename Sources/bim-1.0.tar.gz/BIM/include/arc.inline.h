// -*- c++ -*-
// $Id: arc.inline.h,v 1.1 1997/06/19 19:10:00 pmartin Exp $
#ifndef ARC_INLINE_H
#define ARC_INLINE_H
#ifdef ARC_H
/***********************************************************************/
/*                                                                     */
/*         FUNCTIONS FOR CLASS arc_basic_data                          */
/*                                                                     */
/***********************************************************************/

/*inline void arc_basic_data::swapArcs(arc *e)
{
  arc temp=*e; 
  *e=*this; 
  *this=temp;
}*/


#endif // ARC_H

#endif // End of arc.inline.h

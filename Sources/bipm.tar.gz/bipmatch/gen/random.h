extern void             RandomPermutation();
extern int              RandomInteger();
extern void             InitRandom();
extern void             RandomSubset();

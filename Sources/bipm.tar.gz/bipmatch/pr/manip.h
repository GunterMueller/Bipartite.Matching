extern void 	Init_V();
extern void 	Init_U();
extern void	 AddEdge();

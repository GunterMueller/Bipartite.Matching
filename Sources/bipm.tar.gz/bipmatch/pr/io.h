/* exported routines */

extern void		InputBipartiteGraph();
extern void 		OutputBipartiteGraph();
extern void 		OutputMatching();

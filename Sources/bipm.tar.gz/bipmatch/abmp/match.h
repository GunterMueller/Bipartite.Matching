/* match.h */
extern int Match();

Edge *current[MAX_CARD];

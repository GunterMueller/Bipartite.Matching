/* exported routines */

extern void             BeginTiming();
extern int              EndTiming();
extern int              SampleTime();

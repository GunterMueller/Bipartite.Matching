#define DATA_DIRECTORY "/homes/gws/setubal/netflow/bm/data/" 

#define FAILURE    0
#define SUCCESS    1
#define FALSE      0
#define TRUE       1

typedef char Boolean;

#define INFINITY (1<<30)

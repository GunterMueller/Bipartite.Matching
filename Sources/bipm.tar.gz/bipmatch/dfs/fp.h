extern void     Inits();
extern void	FindPaths();
extern int      eq, eex;
